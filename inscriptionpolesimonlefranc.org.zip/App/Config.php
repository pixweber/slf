<?php
namespace App;

class Config {
    const DB_HOST = 'localhost';
    const DB_NAME = 'slf_dev';
    const DB_USER = 'slf';
    const DB_PASSWORD = '`Lw%:/ek.zB0/8MMB"7K';
    const DB_TYPE = 'mysqli';
    const DB_PORT = '3306';
    const HOURS = array(
        '09h30', '10h00', '10h30', '11h00',
        '11h20', '11h45', '12h10', '12h40',
        '13h00', '14h00', '14h30', '14h45',
        '15h00', '15h15', '15h40', '16h00',
        '16h25', '16h45', '17h00'
    );

    const SITE_URL = 'http://slf.fcciddb.com';
    
    const SMTP_SERVER = 'in-v3.mailjet.com';
    const SMTP_USERNAME = '335ee06aaf6eebeaa4a6ed68d77a798f';
    const SMTP_PASSWORD = 'a249685a91af3acdccaec5de89603e9d';
    const SMTP_SECURE = 'tls';
    const SMTP_PORT = '587';
}