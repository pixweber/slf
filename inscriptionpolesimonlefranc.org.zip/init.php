<?php
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

// Mount autoload
require 'vendor/autoload.php';
require 'utils.php';