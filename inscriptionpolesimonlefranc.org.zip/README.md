# SLF
JDC project for the Pôle Simon le Franc Paris 

## check our website 
http://juniordataconsulting.com/

